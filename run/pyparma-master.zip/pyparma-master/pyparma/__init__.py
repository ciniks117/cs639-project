from __future__ import absolute_import

from .ppl import *
#Note: this import will override the standard Polyhedron
#that is not instantiable anyway
from .utils import Polyhedron
