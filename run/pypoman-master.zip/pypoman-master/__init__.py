# This file allows the whole repository to be used as a submodule.
from .pypoman import *
